var searchData=
[
  ['powerup_5ft_2',['powerup_t',['../structpowerup__t.html',1,'']]]
];
