var indexSectionsWithContent =
{
  0: "bfps",
  1: "bfps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes"
};

