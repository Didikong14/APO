var searchData=
[
  ['powerup_5ft_6',['powerup_t',['../structpowerup__t.html',1,'']]]
];
